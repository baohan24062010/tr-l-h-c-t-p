require("dotenv").config();

const http = require("http");
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, "public");
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini";

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml"
};

function sendJson(res, status, data) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", chunk => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error("Nội dung gửi lên quá dài."));
        req.destroy();
      }
    });
    req.on("end", () => {
      try {
        resolve(JSON.parse(body || "{}"));
      } catch {
        reject(new Error("Dữ liệu gửi lên không hợp lệ."));
      }
    });
    req.on("error", reject);
  });
}

async function handleChat(req, res) {
  if (!API_KEY) {
    return sendJson(res, 500, {
      error: "Chưa cấu hình OPENAI_API_KEY. Hãy tạo file .env và thêm API key theo README.md."
    });
  }

  let payload;
  try {
    payload = await readBody(req);
  } catch (error) {
    return sendJson(res, 400, { error: error.message });
  }

  const messages = Array.isArray(payload.messages) ? payload.messages : [];
  const cleanMessages = messages
    .filter(m => m && ["user", "assistant"].includes(m.role) && typeof m.content === "string")
    .slice(-16)
    .map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));

  if (!cleanMessages.length || !cleanMessages.some(m => m.role === "user")) {
    return sendJson(res, 400, { error: "Bạn hãy nhập câu hỏi trước nhé." });
  }

  const systemPrompt = `Bạn là Mầm Xanh, một trợ lý AI học tập thân thiện dành cho học sinh Việt Nam.
Nhiệm vụ: trả lời câu hỏi văn bản, giải thích kiến thức, hỗ trợ Ngữ văn, Lịch sử, Địa lí, Toán, Khoa học và tiếng Anh.
Quy tắc:
- Trả lời bằng tiếng Việt rõ ràng, đúng trọng tâm; điều chỉnh độ dài theo yêu cầu.
- Với bài tập, trình bày từng bước và nêu lý do, không chỉ đưa đáp án nếu người học cần hiểu cách làm.
- Với câu hỏi về tác phẩm văn học, phân tích nội dung, nghệ thuật và dẫn chứng phù hợp; không bịa trích dẫn.
- Nếu thiếu dữ kiện hoặc không chắc chắn, hãy nói rõ và hỏi thêm thay vì tự bịa.
- Ưu tiên gạch đầu dòng, ví dụ ngắn và cách diễn đạt dễ hiểu.
- Không tuyên bố đã kiểm tra nguồn mới nhất nếu chưa thực sự tra cứu web.
- Giữ giọng điệu tích cực, tôn trọng, không phán xét.`;

  try {
    const apiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: MODEL,
        messages: [
          { role: "system", content: systemPrompt },
          ...cleanMessages
        ],
        temperature: 0.5
      })
    });

    const data = await apiResponse.json();
    if (!apiResponse.ok) {
      const message = data?.error?.message || "Không thể kết nối với dịch vụ AI.";
      return sendJson(res, apiResponse.status, { error: message });
    }

    const answer = data?.choices?.[0]?.message?.content;
    if (!answer) return sendJson(res, 502, { error: "AI chưa trả về câu trả lời. Bạn thử lại nhé." });
    return sendJson(res, 200, { answer });
  } catch (error) {
    return sendJson(res, 502, {
      error: "Không kết nối được AI. Hãy kiểm tra mạng và thử lại."
    });
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  if (req.method === "POST" && url.pathname === "/api/chat") {
    return handleChat(req, res);
  }

  if (req.method !== "GET" && req.method !== "HEAD") {
    res.writeHead(405);
    return res.end("Method Not Allowed");
  }

  let pathname = decodeURIComponent(url.pathname);
  if (pathname === "/") pathname = "/index.html";

  const filePath = path.normalize(path.join(PUBLIC_DIR, pathname));
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }

  fs.readFile(filePath, (error, content) => {
    if (error) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
      return res.end("Không tìm thấy trang.");
    }
    res.writeHead(200, {
      "Content-Type": MIME_TYPES[path.extname(filePath)] || "application/octet-stream"
    });
    if (req.method === "HEAD") return res.end();
    res.end(content);
  });
});

server.listen(PORT, () => {
  console.log(`Mầm Xanh đang chạy tại http://localhost:${PORT}`);
});
