const form = document.getElementById("chatForm");
const input = document.getElementById("questionInput");
const messagesEl = document.getElementById("messages");
const welcome = document.getElementById("welcome");
const sendBtn = document.getElementById("sendBtn");
const newChatBtn = document.getElementById("newChatBtn");
const clearBtn = document.getElementById("clearBtn");

let history = [];
let busy = false;

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

// Hiển thị Markdown cơ bản để câu trả lời dễ đọc hơn.
function renderMarkdown(text) {
  const safe = escapeHtml(text);
  const lines = safe.split("\n");
  let html = "";
  let listType = null;

  const closeList = () => {
    if (listType) {
      html += listType === "ul" ? "</ul>" : "</ol>";
      listType = null;
    }
  };

  for (const rawLine of lines) {
    const line = rawLine.trim();
    const bullet = line.match(/^[-*]\s+(.+)/);
    const numbered = line.match(/^\d+[.)]\s+(.+)/);

    if (bullet || numbered) {
      const type = bullet ? "ul" : "ol";
      if (listType !== type) {
        closeList();
        html += type === "ul" ? "<ul>" : "<ol>";
        listType = type;
      }
      html += `<li>${formatInline((bullet || numbered)[1])}</li>`;
    } else {
      closeList();
      if (!line) continue;
      if (/^###\s+/.test(line)) html += `<p><strong>${formatInline(line.replace(/^###\s+/, ""))}</strong></p>`;
      else if (/^##?\s+/.test(line)) html += `<p><strong>${formatInline(line.replace(/^##?\s+/, ""))}</strong></p>`;
      else html += `<p>${formatInline(line)}</p>`;
    }
  }
  closeList();
  return html;
}

function formatInline(line) {
  return line
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`(.+?)`/g, "<code>$1</code>");
}

function addMessage(role, text, options = {}) {
  welcome.hidden = true;
  const article = document.createElement("article");
  article.className = `message ${role}`;

  if (role === "assistant") {
    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = "✿";
    article.appendChild(avatar);
  }

  const content = document.createElement("div");
  content.className = "message-content";

  if (role === "assistant") {
    const label = document.createElement("div");
    label.className = "message-label";
    label.textContent = "MẦM XANH";
    content.appendChild(label);
  }

  const body = document.createElement("div");
  body.className = "message-text";
  if (options.typing) {
    body.innerHTML = '<div class="typing"><span></span><span></span><span></span></div>';
    body.setAttribute("aria-label", "Đang suy nghĩ");
  } else if (options.error) {
    body.innerHTML = `<div class="error-note">${escapeHtml(text)}</div>`;
  } else {
    body.innerHTML = renderMarkdown(text);
  }

  content.appendChild(body);
  article.appendChild(content);
  messagesEl.appendChild(article);
  scrollToBottom();
  return { article, body };
}

function scrollToBottom() {
  requestAnimationFrame(() => {
    document.querySelector(".chat-area").scrollTop = document.querySelector(".chat-area").scrollHeight;
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  });
}

function setBusy(value) {
  busy = value;
  sendBtn.disabled = value;
  sendBtn.querySelector("span:first-child").textContent = value ? "Đang trả lời..." : "Gửi câu hỏi";
}

function resetChat() {
  if (busy) return;
  history = [];
  messagesEl.innerHTML = "";
  welcome.hidden = false;
  input.value = "";
  input.focus();
  resizeInput();
}

async function sendQuestion(question) {
  const text = question.trim();
  if (!text || busy) return;

  addMessage("user", text);
  history.push({ role: "user", content: text });
  input.value = "";
  resizeInput();
  setBusy(true);
  const pending = addMessage("assistant", "", { typing: true });

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: history })
    });
    const data = await response.json();

    pending.article.remove();
    if (!response.ok) {
      addMessage("assistant", data.error || "Có lỗi xảy ra. Bạn thử lại nhé.", { error: true });
      // Giữ câu hỏi trong lịch sử để người dùng có thể tiếp tục sau khi sửa cấu hình.
    } else {
      history.push({ role: "assistant", content: data.answer });
      addMessage("assistant", data.answer);
    }
  } catch {
    pending.article.remove();
    addMessage("assistant", "Không kết nối được máy chủ. Hãy kiểm tra xem ứng dụng đã chạy trong Visual Studio Code chưa nhé.", { error: true });
  } finally {
    setBusy(false);
    input.focus();
  }
}

function resizeInput() {
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 160) + "px";
}

form.addEventListener("submit", event => {
  event.preventDefault();
  sendQuestion(input.value);
});

input.addEventListener("input", resizeInput);
input.addEventListener("keydown", event => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

document.querySelectorAll("[data-prompt]").forEach(button => {
  button.addEventListener("click", () => {
    input.value = button.dataset.prompt;
    resizeInput();
    input.focus();
  });
});

newChatBtn.addEventListener("click", resetChat);
clearBtn.addEventListener("click", resetChat);
