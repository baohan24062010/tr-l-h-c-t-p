# Mầm Xanh — Trợ lý học tập AI

Ứng dụng web trợ lý học tập có giao diện xanh lá pastel, hỗ trợ hỏi đáp văn bản, phân tích tác phẩm, tóm tắt bài học, lập dàn ý và giải thích bài tập.

## 1. Cần chuẩn bị

- [Node.js](https://nodejs.org/) phiên bản 18 trở lên.
- Visual Studio Code (VS Code).
- API key của OpenAI để bật tính năng trả lời AI. API key có thể phát sinh chi phí theo mức sử dụng.

## 2. Mở dự án trong VS Code

1. Giải nén file ZIP.
2. Mở VS Code → **File → Open Folder...** → chọn thư mục `tro-ly-hoc-tap-pastel`.
3. Mở Terminal trong VS Code: **Terminal → New Terminal**.

## 3. Cấu hình API key

Tạo file tên `.env` trong thư mục dự án, cùng cấp với `server.js`.

Sao chép nội dung từ `.env.example` sang `.env`, sau đó thay bằng API key của bạn:

```env
OPENAI_API_KEY=dan_api_key_cua_ban_o_day
OPENAI_MODEL=gpt-4o-mini
PORT=3000
```

**Quan trọng:** Không chia sẻ API key, không đưa file `.env` lên GitHub và không dán key vào `public/app.js`. Máy chủ sẽ đọc key từ biến môi trường, nhưng phiên bản này chưa có thư viện tự đọc file `.env`. Máy chủ sẽ tự đọc các biến này khi khởi động.

## 4. Cài đặt và chạy ứng dụng

Trong Terminal của VS Code, tại thư mục dự án, chạy:

```bash
npm install
npm start
```

Khi thấy thông báo `Mầm Xanh đang chạy tại http://localhost:3000`, mở trình duyệt và truy cập:

**http://localhost:3000**

Giữ Terminal mở trong khi sử dụng ứng dụng. Nếu sửa file `.env`, hãy khởi động lại máy chủ.

## 5. Tính năng

- Giao diện xanh lá pastel, tương thích điện thoại và máy tính.
- Hỏi đáp bằng tiếng Việt.
- Gợi ý nhanh: phân tích văn học, ôn tập Lịch sử, giải bài tập, lập dàn ý.
- Hiển thị câu trả lời có định dạng cơ bản.
- Lịch sử hội thoại được gửi kèm để AI hiểu ngữ cảnh trong phiên hiện tại.
- API key nằm ở phía máy chủ, không nằm trong mã JavaScript giao diện.

## 6. Xử lý lỗi thường gặp

- **Chưa cấu hình OPENAI_API_KEY:** chạy lại lệnh khởi động và thay bằng API key hợp lệ.
- **Không kết nối được máy chủ:** kiểm tra Terminal còn chạy `node server.js` không.
- **API báo lỗi xác thực hoặc hạn mức:** kiểm tra API key, quyền truy cập API và hạn mức tài khoản.
- **Cổng 3000 đang được sử dụng:** đặt `PORT=3001` trước khi chạy, rồi mở `http://localhost:3001`.

## 7. Lưu ý bảo mật

Bản mẫu phù hợp để chạy trên máy cá nhân. Nếu triển khai công khai, nên bổ sung giới hạn tần suất yêu cầu, xác thực người dùng, kiểm soát chi phí và các biện pháp bảo vệ API. Không đưa API key vào giao diện trình duyệt.
